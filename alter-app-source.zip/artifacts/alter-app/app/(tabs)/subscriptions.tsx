import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Alert,
  Animated,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather, Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';

const { width } = Dimensions.get('window');

type Subscription = {
  id: number;
  name: string;
  price: number;
  unit: string;
  icon: string;
  color: string;
  months: number;
  usage: string;
  cancelled: boolean;
};

const SUBSCRIPTIONS_INITIAL: Subscription[] = [
  {
    id: 1,
    name: 'Netflix',
    price: 57.99,
    unit: 'شهرياً',
    icon: 'N',
    color: '#E50914',
    months: 8,
    usage: 'لم يتم استخدامه مخفوضاً',
    cancelled: false,
  },
  {
    id: 2,
    name: 'Spotify',
    price: 23.99,
    unit: 'شهرياً',
    icon: 'S',
    color: '#1DB954',
    months: 6,
    usage: 'استخدام مخفض',
    cancelled: false,
  },
  {
    id: 3,
    name: 'Adobe Creative',
    price: 84.99,
    unit: 'شهرياً',
    icon: 'A',
    color: '#FF0000',
    months: 12,
    usage: 'لم يتم استخدامه منذ سنة',
    cancelled: false,
  },
];

// Fake sparkline data
const CHART_POINTS = [20, 18, 22, 25, 23, 28, 32, 30, 35, 38, 40, 44];

export default function SubscriptionsScreen() {
  const insets = useSafeAreaInsets();
  const [subs, setSubs] = useState(SUBSCRIPTIONS_INITIAL);
  const investedAnim = useRef(new Animated.Value(287.5)).current;

  const activeSubs = subs.filter((s) => !s.cancelled);
  const cancelledSubs = subs.filter((s) => s.cancelled);
  const totalSaved = cancelledSubs.reduce((acc, s) => acc + s.price, 0);
  const annualGains = (totalSaved * 12 * 0.126).toFixed(2);

  const handleCancel = (id: number) => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Alert.alert(
      '⚡ ضربة قاضية!',
      'سيتم إلغاء الاشتراك وتحويل المبلغ تلقائياً لمحفظتك الاستثمارية كل شهر!',
      [
        { text: 'ألغ الآن', style: 'destructive', onPress: () => {
          setSubs(prev => prev.map(s => s.id === id ? { ...s, cancelled: true } : s));
        }},
        { text: 'تراجع', style: 'cancel' },
      ],
    );
  };

  const chartMax = Math.max(...CHART_POINTS);
  const chartHeight = 80;

  return (
    <View style={styles.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 90 }}
      >
        {/* Header */}
        <View style={[styles.header, { paddingTop: insets.top + 16 }]}>
          <View style={styles.headerLeft}>
            <View style={styles.levelBadge}>
              <Text style={styles.levelText}>lvl 12</Text>
            </View>
          </View>
          <View style={styles.headerRight}>
            <Text style={styles.headerTitle}>إلغاء إشتراكك الخاص</Text>
            <Text style={styles.headerTitle}>بتطبيق الي نسيت منه</Text>
            <Text style={styles.headerSub}>وبضغطة زر حول قيمتها{'\n'}للسهم استثماري بدر لك فوايد 📈</Text>
          </View>
        </View>

        {/* Smart Transfer Card */}
        <View style={styles.transferCard}>
          <View style={styles.transferTop}>
            <View style={styles.chartContainer}>
              <View style={styles.chartBars}>
                {CHART_POINTS.map((pt, i) => (
                  <View
                    key={i}
                    style={{
                      width: 6,
                      height: (pt / chartMax) * chartHeight,
                      backgroundColor: i === CHART_POINTS.length - 1 ? '#10B981' : 'rgba(16,185,129,0.4)',
                      borderRadius: 3,
                      marginHorizontal: 2,
                    }}
                  />
                ))}
              </View>
              <View style={styles.gainBadge}>
                <Text style={styles.gainBadgeText}>+12.6%</Text>
              </View>
            </View>
            <View style={styles.transferInfo}>
              <View style={styles.transferBadge}>
                <MaterialCommunityIcons name="lightning-bolt" size={12} color="#A78BFA" />
                <Text style={styles.transferBadgeText}>تحويل ذكي</Text>
              </View>
              <Text style={styles.transferLabel}>تم تحويل</Text>
              <Text style={styles.transferAmount}>
                {(287.5 + totalSaved).toFixed(2)} SAR
              </Text>
              <Text style={styles.transferSub}>إلى سهم استثماري</Text>
              <View style={styles.returnBadge}>
                <Text style={styles.returnText}>12.6% عائد متوقع سنوي</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Sleeping Subscriptions */}
        {activeSubs.length > 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>😴 اشتراكاتك النائمة</Text>
              <Text style={styles.sectionSub}>اكتشف الاشتراكات التي تدفع لها بدون استخدام</Text>
            </View>

            {activeSubs.map((sub) => (
              <View key={sub.id} style={styles.subCard}>
                <View style={styles.cancelCol}>
                  <TouchableOpacity
                    style={styles.cancelBtn}
                    onPress={() => handleCancel(sub.id)}
                    activeOpacity={0.8}
                  >
                    <Text style={styles.cancelBtnText}>إلغاء وتحويل</Text>
                  </TouchableOpacity>
                  <Text style={styles.subUnit}>{sub.unit}</Text>
                  <Text style={styles.subPrice}>{sub.price} SAR</Text>
                </View>
                <View style={styles.subInfo}>
                  <Text style={styles.subName}>{sub.name}</Text>
                  <Text style={styles.subUsage}>
                    {sub.months === 8 ? 'مشترك منذ 8 أشهر' : sub.months === 6 ? 'مشترك منذ 6 أشهر' : 'مشترك منذ سنة'}
                  </Text>
                  <Text style={[styles.subStatus, { color: sub.id === 2 ? '#F59E0B' : '#EF4444' }]}>
                    {sub.usage}
                  </Text>
                </View>
                <View style={[styles.subIcon, { backgroundColor: sub.color }]}>
                  <Text style={styles.subIconText}>{sub.icon}</Text>
                </View>
              </View>
            ))}
          </View>
        )}

        {/* Cancelled subs section */}
        {cancelledSubs.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>✅ تم الإلغاء والتحويل</Text>
            {cancelledSubs.map((sub) => (
              <View key={sub.id} style={[styles.subCard, styles.cancelledCard]}>
                <View style={styles.cancelledBadge}>
                  <Feather name="check" size={14} color="#10B981" />
                  <Text style={styles.cancelledText}>تم التحويل</Text>
                </View>
                <View style={styles.subInfo}>
                  <Text style={[styles.subName, { color: '#9CA3AF', textDecorationLine: 'line-through' }]}>{sub.name}</Text>
                  <Text style={styles.subSaved}>+{sub.price} SAR / شهرياً للمحفظة</Text>
                </View>
                <View style={[styles.subIcon, { backgroundColor: sub.color, opacity: 0.5 }]}>
                  <Text style={styles.subIconText}>{sub.icon}</Text>
                </View>
              </View>
            ))}
          </View>
        )}

        {/* Totals */}
        <View style={styles.totalsCard}>
          <View style={styles.totalRow}>
            <Text style={styles.totalValue}>
              {(cancelledSubs.reduce((acc, s) => acc + s.price, 0) + 287.5 + activeSubs.reduce((acc, s) => acc + s.price, 0)).toFixed(2)} SAR
            </Text>
            <Text style={styles.totalLabel}>إجمالي المبالغ المحولة</Text>
          </View>
          <View style={styles.totalDivider} />
          <View style={styles.totalRow}>
            <Text style={[styles.totalValue, { color: '#10B981' }]}>{annualGains} SAR</Text>
            <Text style={styles.totalLabel}>إجمالي العوائد المتوقعة سنوياً</Text>
          </View>
          <TouchableOpacity style={styles.portfolioBtn} activeOpacity={0.8}>
            <MaterialCommunityIcons name="chart-line" size={18} color="#FFFFFF" />
            <Text style={styles.portfolioBtnText}>محفظتي الاستثمارية</Text>
          </TouchableOpacity>
        </View>

        {/* Bottom tip */}
        <View style={styles.tipCard}>
          <Ionicons name="bulb-outline" size={20} color="#F59E0B" />
          <Text style={styles.tipText}>
            الاشتراكات المنسية تكلفك أكثر من 1,725 SAR سنوياً — حوّلها واستثمرها! 💡
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#080C10',
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 20,
    flexDirection: 'row-reverse',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
  },
  headerLeft: {},
  headerRight: {
    flex: 1,
    alignItems: 'flex-end',
  },
  levelBadge: {
    backgroundColor: '#1E293B',
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: '#334155',
  },
  levelText: {
    color: '#94A3B8',
    fontSize: 11,
    fontFamily: 'Inter_500Medium',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontFamily: 'Inter_700Bold',
    textAlign: 'right',
    lineHeight: 28,
  },
  headerSub: {
    color: '#6B7280',
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    marginTop: 8,
    lineHeight: 18,
  },
  transferCard: {
    marginHorizontal: 16,
    backgroundColor: '#111827',
    borderRadius: 22,
    padding: 18,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#10B98130',
  },
  transferTop: {
    flexDirection: 'row-reverse',
    gap: 16,
    alignItems: 'flex-end',
  },
  chartContainer: {
    flex: 1,
    position: 'relative',
  },
  chartBars: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    height: 80,
  },
  gainBadge: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderRadius: 10,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: '#10B981',
  },
  gainBadgeText: {
    color: '#10B981',
    fontSize: 12,
    fontFamily: 'Inter_700Bold',
  },
  transferInfo: {
    alignItems: 'flex-end',
    minWidth: 140,
  },
  transferBadge: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#1E1535',
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 4,
    marginBottom: 8,
  },
  transferBadgeText: {
    color: '#A78BFA',
    fontSize: 11,
    fontFamily: 'Inter_500Medium',
  },
  transferLabel: {
    color: '#6B7280',
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
  },
  transferAmount: {
    color: '#FFFFFF',
    fontSize: 26,
    fontFamily: 'Inter_700Bold',
    textAlign: 'right',
  },
  transferSub: {
    color: '#6B7280',
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    marginBottom: 8,
  },
  returnBadge: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: '#10B98150',
  },
  returnText: {
    color: '#10B981',
    fontSize: 10,
    fontFamily: 'Inter_500Medium',
  },
  section: {
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  sectionHeader: {
    alignItems: 'flex-end',
    marginBottom: 12,
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'right',
    marginBottom: 4,
  },
  sectionSub: {
    color: '#6B7280',
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
  },
  subCard: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: '#111827',
    borderRadius: 18,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#1F2937',
    gap: 12,
  },
  cancelledCard: {
    opacity: 0.7,
    borderColor: '#10B98120',
  },
  subIcon: {
    width: 46,
    height: 46,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  subIconText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontFamily: 'Inter_700Bold',
  },
  subInfo: {
    flex: 1,
    alignItems: 'flex-end',
  },
  subName: {
    color: '#FFFFFF',
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'right',
  },
  subUsage: {
    color: '#6B7280',
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    marginTop: 2,
  },
  subStatus: {
    fontSize: 11,
    fontFamily: 'Inter_500Medium',
    textAlign: 'right',
    marginTop: 2,
  },
  subSaved: {
    color: '#10B981',
    fontSize: 12,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'right',
    marginTop: 4,
  },
  cancelCol: {
    alignItems: 'center',
    gap: 4,
  },
  cancelBtn: {
    backgroundColor: '#10B981',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  cancelBtnText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'center',
  },
  subUnit: {
    color: '#9CA3AF',
    fontSize: 10,
    fontFamily: 'Inter_400Regular',
  },
  subPrice: {
    color: '#FFFFFF',
    fontSize: 14,
    fontFamily: 'Inter_700Bold',
  },
  cancelledBadge: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  cancelledText: {
    color: '#10B981',
    fontSize: 11,
    fontFamily: 'Inter_500Medium',
  },
  totalsCard: {
    marginHorizontal: 16,
    backgroundColor: '#111827',
    borderRadius: 22,
    padding: 18,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#1F2937',
  },
  totalRow: {
    alignItems: 'flex-end',
    paddingVertical: 6,
  },
  totalLabel: {
    color: '#6B7280',
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
  },
  totalValue: {
    color: '#FFFFFF',
    fontSize: 24,
    fontFamily: 'Inter_700Bold',
    textAlign: 'right',
  },
  totalDivider: {
    height: 1,
    backgroundColor: '#1F2937',
    marginVertical: 10,
  },
  portfolioBtn: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#7C3AED',
    borderRadius: 22,
    paddingVertical: 12,
    marginTop: 14,
  },
  portfolioBtnText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
  },
  tipCard: {
    marginHorizontal: 16,
    marginBottom: 16,
    backgroundColor: '#1A1200',
    borderRadius: 16,
    padding: 14,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 10,
    borderWidth: 1,
    borderColor: '#F59E0B30',
  },
  tipText: {
    flex: 1,
    color: '#FCD34D',
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    lineHeight: 18,
  },
});
