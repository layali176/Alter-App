import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Animated,
  Easing,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather, Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';

const FAMILY_MEMBERS = [
  { id: 1, name: 'أم فهد', reaction: 'محد يشبعك! 😅', time: '11:48 م', status: 'warning', avatar: '👩' },
  { id: 2, name: 'أبو فهد', reaction: 'يا ولن الأرباح! 😤', time: '11:48 م', status: 'danger', avatar: '👨' },
  { id: 3, name: 'أخت فهد', reaction: 'خل عنك الكيك بعد! 😂', time: '11:48 م', status: 'laugh', avatar: '👧' },
  { id: 4, name: 'أخو فهد', reaction: 'احتمالك تخسر التحدي 💪', time: '11:48 م', status: 'challenge', avatar: '👦' },
];

export default function RadarScreen() {
  const insets = useSafeAreaInsets();
  const radarAnim = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const [dangerLevel, setDangerLevel] = useState(4);

  useEffect(() => {
    // Radar rotation animation
    Animated.loop(
      Animated.timing(radarAnim, {
        toValue: 1,
        duration: 3000,
        easing: Easing.linear,
        useNativeDriver: true,
      }),
    ).start();

    // Pulse animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.08,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
      ]),
    ).start();
  }, []);

  const radarRotate = radarAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  const handleChallenge = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    setDangerLevel(Math.max(1, dangerLevel - 1));
  };

  return (
    <View style={styles.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 90 }}
      >
        {/* Header */}
        <View style={[styles.header, { paddingTop: insets.top + 16 }]}>
          <View style={styles.headerRight}>
            <Text style={styles.headerTitle}>رادار التنبيه العائلي ⚡</Text>
            <Text style={styles.headerSub}>للضلال المشتركة</Text>
            <Text style={styles.headerDesc}>
              إشعارات فكاهية جماعية تُطلق لهواتف العائلة{'\n'}عند قيام أحد الأبناء بإنفاق عشوائي 😂
            </Text>
          </View>
          <View style={styles.sirenContainer}>
            <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>
              <MaterialCommunityIcons name="alarm-light" size={32} color="#EF4444" />
            </Animated.View>
          </View>
        </View>

        {/* Shared Goals */}
        <View style={styles.goalsSection}>
          <Text style={styles.goalsSectionTitle}>🎯 الأهداف المشتركة للعائلة</Text>

          <View style={styles.goalCard}>
            <View style={styles.goalCardHeader}>
              <Text style={styles.goalPercent}>45%</Text>
              <View style={styles.goalCardTitleRow}>
                <MaterialCommunityIcons name="handshake" size={16} color="#7C3AED" />
                <Text style={styles.goalCardTitle}>الادخار لتمويل مشروعنا العائلي</Text>
              </View>
            </View>
            <View style={styles.goalBarBg}>
              <View style={[styles.goalBarFill, { width: '45%', backgroundColor: '#7C3AED' }]} />
            </View>
            <View style={styles.goalCardFooter}>
              <Text style={styles.goalTarget}>الهدف: 50,000 ريال</Text>
              <Text style={styles.goalSaved}>تم ادخار: 22,500 ريال</Text>
            </View>
          </View>

          <View style={styles.goalCard}>
            <View style={styles.goalCardHeader}>
              <Text style={[styles.goalPercent, { color: '#10B981' }]}>28%</Text>
              <View style={styles.goalCardTitleRow}>
                <MaterialCommunityIcons name="airplane" size={16} color="#10B981" />
                <Text style={styles.goalCardTitle}>الادخار لسفرة الصيف</Text>
              </View>
            </View>
            <View style={styles.goalBarBg}>
              <View style={[styles.goalBarFill, { width: '28%', backgroundColor: '#10B981' }]} />
            </View>
            <View style={styles.goalCardFooter}>
              <Text style={styles.goalTarget}>الهدف: 15,000 ريال</Text>
              <Text style={[styles.goalSaved, { color: '#10B981' }]}>تم ادخار: 4,200 ريال</Text>
            </View>
          </View>
        </View>

        {/* Radar */}
        <View style={styles.radarSection}>
          {/* Side reactions */}
          <View style={styles.sideLeft}>
            <View style={styles.sideReaction}>
              <Text style={styles.sideText}>شفتنا!</Text>
            </View>
          </View>
          <View style={styles.sideRight}>
            <View style={styles.sideReaction}>
              <Text style={styles.sideText}>فهد بيلتنا{'\n'}ميزانية خاصة{'\n'}خاصة</Text>
            </View>
          </View>

          <View style={styles.radarWrapper}>
            {/* Radar circles */}
            <View style={styles.radarOuter}>
              <View style={styles.radarMiddle}>
                <View style={styles.radarInner}>
                  <View style={styles.radarCenter}>
                    <Text style={styles.radarCenterEmoji}>🕴️</Text>
                    <Text style={styles.radarCenterLabel}>فهد</Text>
                    <Text style={styles.radarTargetLabel}>هدف الرادار اليوم 🎯</Text>
                  </View>
                </View>
              </View>
            </View>

            {/* Rotating scanner beam */}
            <Animated.View
              style={[
                styles.radarBeam,
                { transform: [{ rotate: radarRotate }] },
              ]}
            />
          </View>

          {/* Stats */}
          <View style={styles.radarStats}>
            <View style={styles.radarStat}>
              <Text style={styles.radarStatLabel}>قوة التحمل العائلي</Text>
              <Text style={styles.radarStatValue}>62% 💪</Text>
              <View style={styles.progressBg}>
                <View style={[styles.progressFill, { width: '62%' }]} />
              </View>
            </View>
            <View style={styles.radarStatDivider} />
            <View style={styles.radarStat}>
              <Text style={styles.radarStatLabel}>مستوى الخطر</Text>
              <Text style={[styles.radarStatValue, { color: '#EF4444' }]}>مرتفع 🔴</Text>
              <View style={styles.dangerBars}>
                {Array.from({ length: 6 }).map((_, i) => (
                  <View
                    key={i}
                    style={[
                      styles.dangerBar,
                      i < dangerLevel ? styles.dangerBarActive : styles.dangerBarInactive,
                    ]}
                  />
                ))}
              </View>
            </View>
          </View>
        </View>

        <View style={styles.content}>
          {/* Alert Card */}
          <View style={styles.alertCard}>
            <View style={styles.alertHeader}>
              <View style={styles.alertBadge}>
                <Text style={styles.alertBadgeText}>⚠️</Text>
              </View>
              <Text style={styles.alertTitle}>
                فهد طالب اكل للمرة <Text style={styles.alertHighlight}>الخامسة</Text> ذا الشهر ويزيد وزنه! 😂
              </Text>
            </View>
            <View style={styles.alertMeta}>
              <Text style={styles.alertTime}>⏰ أحد طلبات البرجر الساعة 11:47 م</Text>
              <Text style={styles.alertAmount}>- 87.50 SAR 💸</Text>
            </View>
          </View>

          {/* Family Reactions */}
          <Text style={styles.sectionTitle}>😂 ردود فعل العائلة اللحظية</Text>
          <View style={styles.familyGrid}>
            {FAMILY_MEMBERS.map((member) => (
              <TouchableOpacity
                key={member.id}
                style={styles.familyCard}
                onPress={() => Haptics.selectionAsync()}
                activeOpacity={0.8}
              >
                <Text style={styles.familyAvatar}>{member.avatar}</Text>
                <Text style={styles.familyName}>{member.name}</Text>
                <Text style={styles.familyReaction}>{member.reaction}</Text>
                <Text style={styles.familyTime}>الآن {member.time}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Family Advice */}
          <View style={styles.adviceCard}>
            <View style={styles.adviceHeader}>
              <MaterialCommunityIcons name="trophy" size={20} color="#F59E0B" />
              <Text style={styles.adviceTitle}>نصيحة العائلة الذهبية 👑</Text>
            </View>
            <Text style={styles.adviceText}>
              اشبع جسمك مو عينيك 🧠💡{'\n'}
              عشان ما نشتري لك ميزان جديد 😂
            </Text>
            <TouchableOpacity style={styles.challengeBtn} onPress={handleChallenge} activeOpacity={0.8}>
              <Text style={styles.challengeBtnText}>✅ قبلت التحدي! تخفيض مستوى الخطر</Text>
            </TouchableOpacity>
          </View>

          {/* Points Card */}
          <View style={styles.pointsCard}>
            <View style={styles.pointsHeader}>
              <View style={styles.pointsBadge}>
                <Text style={styles.pointsBadgeText}>نقاط العائلة</Text>
                <Text style={styles.pointsBadgeValue}>⭐ 2,450</Text>
              </View>
              <Text style={styles.pointsTitle}>✨ مكافأة ضبط المصاريف</Text>
              <Text style={styles.pointsSub}>كل ما قلت طلبات فهد العشوائية، الكل يكسب!</Text>
            </View>
            <View style={styles.pointsProgress}>
              <View style={styles.pointsBar}>
                <View style={[styles.pointsBarFill, { width: '49%' }]} />
                <View style={styles.pointsLock}>
                  <Feather name="lock" size={10} color="#9CA3AF" />
                </View>
              </View>
              <View style={styles.pointsLabels}>
                <Text style={styles.pointsLabel}>5,000 نقطة</Text>
                <Text style={styles.pointsLabel}>3,000 نقطة</Text>
                <Text style={styles.pointsLabel}>1,000 نقطة</Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0D0821',
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 16,
    flexDirection: 'row-reverse',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
  },
  headerRight: {
    flex: 1,
    alignItems: 'flex-end',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontFamily: 'Inter_700Bold',
    textAlign: 'right',
  },
  headerSub: {
    color: '#A78BFA',
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    marginBottom: 8,
  },
  headerDesc: {
    color: '#9CA3AF',
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    lineHeight: 16,
  },
  sirenContainer: {
    marginLeft: 16,
    paddingTop: 4,
  },
  radarSection: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 20,
    position: 'relative',
    height: 280,
  },
  sideLeft: {
    position: 'absolute',
    left: 16,
    top: '30%',
  },
  sideRight: {
    position: 'absolute',
    right: 16,
    top: '30%',
  },
  sideReaction: {
    backgroundColor: 'rgba(124,58,237,0.3)',
    borderRadius: 12,
    padding: 8,
    borderWidth: 1,
    borderColor: '#7C3AED',
    maxWidth: 80,
  },
  sideText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontFamily: 'Inter_400Regular',
    textAlign: 'center',
  },
  radarWrapper: {
    width: 200,
    height: 200,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  radarOuter: {
    width: 200,
    height: 200,
    borderRadius: 100,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(16,185,129,0.05)',
  },
  radarMiddle: {
    width: 140,
    height: 140,
    borderRadius: 70,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(16,185,129,0.08)',
  },
  radarInner: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(16,185,129,0.15)',
  },
  radarCenter: {
    alignItems: 'center',
  },
  radarCenterEmoji: {
    fontSize: 22,
  },
  radarCenterLabel: {
    color: '#FFFFFF',
    fontSize: 11,
    fontFamily: 'Inter_700Bold',
  },
  radarTargetLabel: {
    position: 'absolute',
    top: 64,
    color: '#10B981',
    fontSize: 8,
    fontFamily: 'Inter_500Medium',
    width: 100,
    textAlign: 'center',
  },
  radarBeam: {
    position: 'absolute',
    width: 100,
    height: 2,
    right: 100,
    top: 99,
    backgroundColor: 'rgba(16,185,129,0.6)',
    transformOrigin: 'right center',
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
  },
  radarStats: {
    position: 'absolute',
    bottom: 8,
    left: 20,
    right: 20,
    flexDirection: 'row-reverse',
    gap: 12,
  },
  radarStat: {
    flex: 1,
    alignItems: 'flex-end',
  },
  radarStatLabel: {
    color: '#9CA3AF',
    fontSize: 10,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    marginBottom: 2,
  },
  radarStatValue: {
    color: '#A78BFA',
    fontSize: 13,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'right',
    marginBottom: 4,
  },
  progressBg: {
    height: 4,
    width: '100%',
    backgroundColor: '#2D2040',
    borderRadius: 2,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#A78BFA',
    borderRadius: 2,
  },
  radarStatDivider: {
    width: 1,
    backgroundColor: '#2D2040',
  },
  dangerBars: {
    flexDirection: 'row-reverse',
    gap: 3,
  },
  dangerBar: {
    width: 8,
    height: 14,
    borderRadius: 2,
  },
  dangerBarActive: {
    backgroundColor: '#EF4444',
  },
  dangerBarInactive: {
    backgroundColor: '#2D2040',
  },
  goalsSection: {
    paddingHorizontal: 16,
    marginBottom: 8,
    gap: 10,
  },
  goalsSectionTitle: {
    color: '#FFFFFF',
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'right',
    marginBottom: 4,
  },
  goalCard: {
    backgroundColor: '#14101E',
    borderRadius: 18,
    padding: 14,
    borderWidth: 1,
    borderColor: '#2D2040',
    gap: 8,
  },
  goalCardHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  goalCardTitleRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 6,
    flex: 1,
  },
  goalCardTitle: {
    color: '#FFFFFF',
    fontSize: 13,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'right',
    flex: 1,
  },
  goalPercent: {
    color: '#7C3AED',
    fontSize: 16,
    fontFamily: 'Inter_700Bold',
    marginLeft: 8,
  },
  goalBarBg: {
    height: 6,
    backgroundColor: '#2D2040',
    borderRadius: 3,
    overflow: 'hidden',
  },
  goalBarFill: {
    height: '100%',
    borderRadius: 3,
  },
  goalCardFooter: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
  },
  goalTarget: {
    color: '#6B7280',
    fontSize: 10,
    fontFamily: 'Inter_400Regular',
  },
  goalSaved: {
    color: '#A78BFA',
    fontSize: 10,
    fontFamily: 'Inter_600SemiBold',
  },
  content: {
    paddingHorizontal: 16,
  },
  alertCard: {
    backgroundColor: '#1A0A14',
    borderRadius: 20,
    padding: 16,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#EF444440',
  },
  alertHeader: {
    flexDirection: 'row-reverse',
    gap: 10,
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  alertBadge: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#7F1D1D',
    alignItems: 'center',
    justifyContent: 'center',
  },
  alertBadgeText: {
    fontSize: 14,
  },
  alertTitle: {
    flex: 1,
    color: '#FFFFFF',
    fontSize: 14,
    fontFamily: 'Inter_500Medium',
    textAlign: 'right',
    lineHeight: 22,
  },
  alertHighlight: {
    color: '#EF4444',
    fontFamily: 'Inter_700Bold',
  },
  alertMeta: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#2D2040',
    paddingTop: 10,
  },
  alertTime: {
    color: '#9CA3AF',
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
  },
  alertAmount: {
    color: '#EF4444',
    fontSize: 18,
    fontFamily: 'Inter_700Bold',
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'right',
    marginBottom: 12,
  },
  familyGrid: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 14,
  },
  familyCard: {
    width: '47%',
    backgroundColor: '#14101E',
    borderRadius: 18,
    padding: 14,
    alignItems: 'flex-end',
    borderWidth: 1,
    borderColor: '#2D2040',
  },
  familyAvatar: {
    fontSize: 28,
    marginBottom: 6,
  },
  familyName: {
    color: '#FFFFFF',
    fontSize: 13,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'right',
  },
  familyReaction: {
    color: '#A78BFA',
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    marginTop: 4,
    lineHeight: 16,
  },
  familyTime: {
    color: '#6B7280',
    fontSize: 10,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    marginTop: 4,
  },
  adviceCard: {
    backgroundColor: '#14101E',
    borderRadius: 20,
    padding: 16,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#F59E0B40',
  },
  adviceHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 8,
    marginBottom: 10,
  },
  adviceTitle: {
    color: '#FFFFFF',
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
  },
  adviceText: {
    color: '#D1D5DB',
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    lineHeight: 22,
    marginBottom: 14,
  },
  challengeBtn: {
    backgroundColor: '#065F46',
    borderRadius: 22,
    paddingVertical: 12,
    alignItems: 'center',
  },
  challengeBtnText: {
    color: '#6EE7B7',
    fontSize: 13,
    fontFamily: 'Inter_600SemiBold',
  },
  pointsCard: {
    backgroundColor: '#14101E',
    borderRadius: 20,
    padding: 16,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#2D2040',
  },
  pointsHeader: {
    alignItems: 'flex-end',
    marginBottom: 14,
  },
  pointsBadge: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#2D2040',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginBottom: 8,
    alignSelf: 'flex-start',
  },
  pointsBadgeText: {
    color: '#9CA3AF',
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
  },
  pointsBadgeValue: {
    color: '#F59E0B',
    fontSize: 13,
    fontFamily: 'Inter_700Bold',
  },
  pointsTitle: {
    color: '#FFFFFF',
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'right',
  },
  pointsSub: {
    color: '#9CA3AF',
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    marginTop: 4,
  },
  pointsProgress: {
    gap: 6,
  },
  pointsBar: {
    height: 8,
    backgroundColor: '#2D2040',
    borderRadius: 4,
    position: 'relative',
    overflow: 'hidden',
  },
  pointsBarFill: {
    height: '100%',
    backgroundColor: '#F59E0B',
    borderRadius: 4,
  },
  pointsLock: {
    position: 'absolute',
    top: -3,
    left: '50%',
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#2D2040',
    alignItems: 'center',
    justifyContent: 'center',
  },
  pointsLabels: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
  },
  pointsLabel: {
    color: '#6B7280',
    fontSize: 10,
    fontFamily: 'Inter_400Regular',
  },
});
