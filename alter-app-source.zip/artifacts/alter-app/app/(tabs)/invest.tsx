import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Image,
  StyleSheet,
  Alert,
  Animated,
  Easing,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather, Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';

const CERTS = [
  { id: 1, name: 'شهادة تحليل مالي\nCFA Level 1', progress: 60, color: '#7C3AED', cost: 3200 },
  { id: 2, name: 'شهادة محاسبة\nACCA', progress: 25, color: '#F59E0B', cost: 2800 },
  { id: 3, name: 'إدارة مشاريع\nPMP', progress: 10, color: '#10B981', cost: 1800 },
];

const FEATURES = [
  { id: 1, icon: '🐷', title: 'ادخر بسهولة', desc: 'اقتطع تلقائياً من مصروفك الشهري' },
  { id: 2, icon: '🧩', title: 'نستثمر لك', desc: 'في محافظ ذكية منخفضة المخاطر' },
  { id: 3, icon: '📈', title: 'عوائد مستمرة', desc: 'نعيد استثمار العوائد لتحقيق نمو أكبر' },
  { id: 4, icon: '🎓', title: 'مؤل شهادتك', desc: 'نغطي تكلفة الشهادة عند تحقيق الهدف' },
];

const GRAD_CERTS = [
  { id: 'cfa',  label: 'CFA',  color: '#7C3AED', icon: '📊' },
  { id: 'frm',  label: 'FRM',  color: '#F59E0B', icon: '🛡️' },
  { id: 'cpa',  label: 'CPA',  color: '#10B981', icon: '🧮' },
  { id: 'pmp',  label: 'PMP',  color: '#3B82F6', icon: '📋' },
];

export default function InvestScreen() {
  const insets = useSafeAreaInsets();
  const [selectedCert, setSelectedCert] = useState(0);
  const [autoInvest, setAutoInvest] = useState(true);

  // Graduate card interactive state
  const [unlockedCerts, setUnlockedCerts] = useState<string[]>([]);
  const [portfolioVal, setPortfolioVal] = useState(0);
  const floatAnim   = useRef(new Animated.Value(0)).current;
  const glowAnim    = useRef(new Animated.Value(0.6)).current;
  const certScales  = useRef(GRAD_CERTS.map(() => new Animated.Value(1))).current;
  const counterAnim = useRef(new Animated.Value(0)).current;

  // Floating loop
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(floatAnim, { toValue: -12, duration: 1600, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(floatAnim, { toValue: 0,   duration: 1600, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ])
    ).start();
    // Glow pulse
    Animated.loop(
      Animated.sequence([
        Animated.timing(glowAnim, { toValue: 1,   duration: 1200, useNativeDriver: true }),
        Animated.timing(glowAnim, { toValue: 0.5, duration: 1200, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  const handleUnlockCert = (idx: number) => {
    const cert = GRAD_CERTS[idx];
    if (unlockedCerts.includes(cert.id)) return;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    // Pop scale
    Animated.sequence([
      Animated.timing(certScales[idx], { toValue: 1.35, duration: 150, useNativeDriver: true }),
      Animated.spring(certScales[idx],  { toValue: 1,    useNativeDriver: true }),
    ]).start();
    const next = [...unlockedCerts, cert.id];
    setUnlockedCerts(next);
    // Animate counter up
    const target = next.length * 587500;
    counterAnim.stopAnimation();
    Animated.timing(counterAnim, { toValue: target, duration: 900, easing: Easing.out(Easing.quad), useNativeDriver: false }).start();
    counterAnim.addListener(({ value }) => setPortfolioVal(Math.round(value)));
  };

  const handleInvest = () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Alert.alert('🎉 ممتاز!', 'تم تفعيل الاستثمار التلقائي!\nسيتم خصم 100 ريال شهرياً لتمويل شهادتك.');
  };

  const cert = CERTS[selectedCert];

  return (
    <View style={styles.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 90 }}
      >
        {/* Hero section */}
        <View style={[styles.heroSection, { paddingTop: insets.top + 16 }]}>
          <View style={styles.heroTop}>
            <View style={styles.notifBtn}>
              <Ionicons name="notifications-outline" size={22} color="#FFFFFF" />
              <View style={styles.notifDot} />
            </View>
            <View style={styles.userRow}>
              <View>
                <Text style={styles.userGreeting}>مرحبا، فهد 👋</Text>
                <Text style={styles.userLevel}>Lv.12</Text>
              </View>
              <View style={styles.heroAvatar}>
                <Text style={styles.heroAvatarText}>🕴️</Text>
              </View>
            </View>
          </View>

          {/* Hero Text */}
          <View style={styles.heroTextBlock}>
            <Text style={styles.heroTitle}>استثمر مدخراتك اليوم</Text>
            <Text style={styles.heroTitle}>لشهاداتك ونجاحك غداً 🎓</Text>
            <Text style={styles.heroSubtitle}>
              نستثمر مدخراتك البسيطة تلقائياً{'\n'}لتمويل شهاداتك الاحترافية وبناء مستقبلك المالي 🌱
            </Text>
          </View>

          {/* Cert selector pill */}
          <View style={styles.certSelector}>
            <Text style={styles.certSelectorLabel}>الخطوة التالية</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingRight: 4 }}>
              {CERTS.map((c, i) => (
                <TouchableOpacity
                  key={c.id}
                  style={[styles.certPill, selectedCert === i && styles.certPillActive]}
                  onPress={() => {
                    setSelectedCert(i);
                    Haptics.selectionAsync();
                  }}
                  activeOpacity={0.8}
                >
                  <Text style={[styles.certPillText, selectedCert === i && styles.certPillTextActive]}>
                    {c.name.split('\n')[0]}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <View style={styles.certProgress}>
              <View style={styles.certProgressInfo}>
                <Text style={styles.certProgressLabel}>{cert.name}</Text>
                <Text style={styles.certProgressPct}>{cert.progress}%</Text>
              </View>
              <View style={styles.progressBarBg}>
                <View style={[styles.progressBarFill, { width: `${cert.progress}%`, backgroundColor: cert.color }]} />
              </View>
            </View>
          </View>

        </View>

        <View style={styles.contentPad}>
          {/* Active Savings */}
          <View style={styles.savingsCard}>
            <View style={styles.savingsHeader}>
              <View style={styles.jarContainer}>
                <Text style={styles.jarEmoji}>🏺</Text>
                <View style={styles.jarLabel}>
                  <Text style={styles.jarLabelText}>نحو{'\n'}شهادتك{'\n'}الاحترافية</Text>
                </View>
              </View>
              <View style={styles.savingsInfo}>
                <Text style={styles.savingsLabel}>مدخراتك النشطة 📈</Text>
                <Text style={styles.savingsAmount}>8,450.50 SAR</Text>
                <Text style={styles.savingsTotal}>إجمالي المدخرات المستثمرة</Text>
                <Text style={styles.savingsGain}>+1,245.30 SAR (+17.3%)</Text>
                <Text style={styles.savingsGainLabel}>العوائد المحققة حتى الآن ⓘ</Text>
              </View>
            </View>

            <View style={styles.metaRow}>
              <View style={styles.metaItem}>
                <MaterialCommunityIcons name="trending-up" size={16} color="#10B981" />
                <Text style={styles.metaValue}>12.4%</Text>
                <Text style={styles.metaLabel}>العائد السنوي المتوقع</Text>
              </View>
              <View style={styles.metaDivider} />
              <View style={styles.metaItem}>
                <Feather name="clock" size={16} color="#F59E0B" />
                <Text style={styles.metaValue}>2 سنوات</Text>
                <Text style={styles.metaLabel}>الوقت المتبقي للتخرج</Text>
              </View>
              <View style={styles.metaDivider} />
              <View style={styles.metaItem}>
                <Ionicons name="flag-outline" size={16} color="#EF4444" />
                <Text style={styles.metaValue}>15,000 SAR</Text>
                <Text style={styles.metaLabel}>المبلغ المطلوب</Text>
              </View>
            </View>
          </View>

          {/* Auto invest toggle */}
          <View style={styles.autoInvestCard}>
            <View style={styles.autoInvestLeft}>
              <Text style={styles.autoInvestTitle}>استثمارك التلقائي ⚡</Text>
              <Text style={styles.autoInvestSub}>100 SAR / شهرياً</Text>
            </View>
            <TouchableOpacity
              style={[styles.toggle, autoInvest && styles.toggleActive]}
              onPress={() => {
                setAutoInvest(!autoInvest);
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              }}
              activeOpacity={0.8}
            >
              <View style={[styles.toggleThumb, autoInvest && styles.toggleThumbActive]} />
            </TouchableOpacity>
          </View>

          {/* Features */}
          <Text style={styles.featuresTitle}>كيف يعمل الاستثمار التلقائي؟ 🧠</Text>
          <View style={styles.featuresGrid}>
            {FEATURES.map((f) => (
              <View key={f.id} style={styles.featureCard}>
                <Text style={styles.featureIcon}>{f.icon}</Text>
                <Text style={styles.featureTitle}>{f.title}</Text>
                <Text style={styles.featureDesc}>{f.desc}</Text>
              </View>
            ))}
          </View>

          {/* Future self card — interactive */}
          <View style={styles.futureCard}>
            <Text style={styles.futureTitle}>أول متخرج وأول مستثمر ذكي 🎓</Text>
            <Text style={styles.futureText}>
              اضغط على الشهادات وشوف محفظتك تكبر 💜
            </Text>

            {/* Character floating */}
            <View style={styles.charScene}>
              {/* Glow */}
              <Animated.View style={[styles.charGlow, { opacity: glowAnim }]} />

              <Animated.Image
                source={require('@/assets/images/grad-char2.png')}
                style={[styles.gradCharImg, { transform: [{ translateY: floatAnim }] }]}
                resizeMode="contain"
              />
            </View>

            {/* Portfolio counter */}
            <View style={styles.portfolioRow}>
              <Text style={styles.portfolioLabel}>محفظتي الاستثمارية</Text>
              <Text style={styles.portfolioValue}>
                {portfolioVal.toLocaleString('ar-SA')} SAR
              </Text>
              {unlockedCerts.length > 0 && (
                <Text style={styles.portfolioReturn}>+28.5% العائد السنوي 📈</Text>
              )}
            </View>

            {/* Cert badges — tap to unlock */}
            <Text style={styles.certsHint}>
              {unlockedCerts.length === 4 ? '🏆 أنجزت كل الشهادات!' : 'اضغط لفتح شهادة 👆'}
            </Text>
            <View style={styles.certsRow}>
              {GRAD_CERTS.map((c, i) => {
                const unlocked = unlockedCerts.includes(c.id);
                return (
                  <Animated.View key={c.id} style={{ transform: [{ scale: certScales[i] }] }}>
                    <TouchableOpacity
                      style={[
                        styles.certBadge,
                        { borderColor: c.color, backgroundColor: unlocked ? c.color + '33' : '#1A0A2E' },
                      ]}
                      onPress={() => handleUnlockCert(i)}
                      activeOpacity={0.7}
                    >
                      <Text style={styles.certIcon}>{unlocked ? c.icon : '🔒'}</Text>
                      <Text style={[styles.certLabel, { color: unlocked ? c.color : '#6B7280' }]}>
                        {c.label}
                      </Text>
                      {unlocked && <Text style={styles.certCheck}>✅</Text>}
                    </TouchableOpacity>
                  </Animated.View>
                );
              })}
            </View>

            <TouchableOpacity style={styles.futureBtn} onPress={handleInvest} activeOpacity={0.8}>
              <Text style={styles.futureBtnText}>🚀 مستقبلك يبدأ من قرار اليوم</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F0F4FF',
  },
  heroSection: {
    backgroundColor: '#7C3AED',
    paddingHorizontal: 20,
    paddingBottom: 100,
    borderBottomLeftRadius: 36,
    borderBottomRightRadius: 36,
    overflow: 'hidden',
  },
  heroTop: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  userRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 10,
  },
  heroAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroAvatarText: {
    fontSize: 22,
  },
  userGreeting: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'right',
  },
  userLevel: {
    color: '#DDD6FE',
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
    textAlign: 'right',
  },
  notifBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  notifDot: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#EF4444',
  },
  heroTextBlock: {
    alignItems: 'flex-end',
    marginBottom: 20,
  },
  heroTitle: {
    color: '#FFFFFF',
    fontSize: 22,
    fontFamily: 'Inter_700Bold',
    textAlign: 'right',
    lineHeight: 30,
  },
  heroSubtitle: {
    color: '#DDD6FE',
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    marginTop: 8,
    lineHeight: 18,
  },
  certSelector: {
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: 20,
    padding: 14,
    alignItems: 'flex-end',
  },
  certSelectorLabel: {
    color: '#DDD6FE',
    fontSize: 11,
    fontFamily: 'Inter_500Medium',
    marginBottom: 8,
  },
  certPill: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  certPillActive: {
    backgroundColor: '#FFFFFF',
  },
  certPillText: {
    color: '#DDD6FE',
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
  },
  certPillTextActive: {
    color: '#7C3AED',
    fontFamily: 'Inter_600SemiBold',
  },
  certProgress: {
    width: '100%',
    marginTop: 12,
  },
  certProgressInfo: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  certProgressLabel: {
    color: '#FFFFFF',
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
    textAlign: 'right',
  },
  certProgressPct: {
    color: '#A78BFA',
    fontSize: 13,
    fontFamily: 'Inter_700Bold',
  },
  progressBarBg: {
    height: 6,
    borderRadius: 3,
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 3,
  },
  investChar: {
    position: 'absolute',
    bottom: -20,
    left: -10,
    width: 180,
    height: 180,
    opacity: 0.9,
  },
  contentPad: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  savingsCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 24,
    padding: 18,
    marginBottom: 14,
    shadowColor: '#7C3AED',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  savingsHeader: {
    flexDirection: 'row-reverse',
    gap: 12,
    marginBottom: 16,
  },
  jarContainer: {
    position: 'relative',
    width: 80,
  },
  jarEmoji: {
    fontSize: 56,
  },
  jarLabel: {
    position: 'absolute',
    bottom: 8,
    right: 4,
    backgroundColor: '#7C3AED',
    borderRadius: 8,
    paddingHorizontal: 4,
    paddingVertical: 2,
  },
  jarLabelText: {
    color: '#FFFFFF',
    fontSize: 7,
    fontFamily: 'Inter_700Bold',
    textAlign: 'center',
  },
  savingsInfo: {
    flex: 1,
    alignItems: 'flex-end',
  },
  savingsLabel: {
    color: '#6B7280',
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
    marginBottom: 4,
  },
  savingsAmount: {
    color: '#7C3AED',
    fontSize: 28,
    fontFamily: 'Inter_700Bold',
  },
  savingsTotal: {
    color: '#9CA3AF',
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
  },
  savingsGain: {
    color: '#10B981',
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    marginTop: 4,
  },
  savingsGainLabel: {
    color: '#9CA3AF',
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
  },
  metaRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
    paddingTop: 14,
  },
  metaItem: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  metaDivider: {
    width: 1,
    backgroundColor: '#F3F4F6',
  },
  metaValue: {
    color: '#1A1A2E',
    fontSize: 14,
    fontFamily: 'Inter_700Bold',
    textAlign: 'center',
  },
  metaLabel: {
    color: '#9CA3AF',
    fontSize: 9,
    fontFamily: 'Inter_400Regular',
    textAlign: 'center',
  },
  autoInvestCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 16,
    marginBottom: 14,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1.5,
    borderColor: '#EDE9FE',
  },
  autoInvestLeft: {
    alignItems: 'flex-end',
  },
  autoInvestTitle: {
    color: '#1A1A2E',
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
  },
  autoInvestSub: {
    color: '#7C3AED',
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
    marginTop: 2,
  },
  toggle: {
    width: 52,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#E5E7EB',
    padding: 2,
    justifyContent: 'center',
  },
  toggleActive: {
    backgroundColor: '#7C3AED',
  },
  toggleThumb: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
  },
  toggleThumbActive: {
    alignSelf: 'flex-end',
  },
  featuresTitle: {
    color: '#1A1A2E',
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'right',
    marginBottom: 12,
  },
  featuresGrid: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 14,
  },
  featureCard: {
    width: '47%',
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 14,
    alignItems: 'flex-end',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  featureIcon: {
    fontSize: 28,
    marginBottom: 8,
  },
  featureTitle: {
    color: '#1A1A2E',
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'right',
    marginBottom: 4,
  },
  featureDesc: {
    color: '#6B7280',
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    lineHeight: 16,
  },
  futureCard: {
    backgroundColor: '#1A0A2E',
    borderRadius: 22,
    padding: 20,
    marginBottom: 16,
    alignItems: 'flex-end',
    borderWidth: 1,
    borderColor: '#7C3AED60',
    overflow: 'hidden',
  },
  futureTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontFamily: 'Inter_700Bold',
    textAlign: 'right',
    marginBottom: 8,
  },
  futureText: {
    color: '#C4B5FD',
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    lineHeight: 20,
    marginBottom: 16,
  },

  // ── Graduate interactive scene ────────────────────────────────
  charScene: {
    width: '100%',
    height: 260,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
    position: 'relative',
  },
  charGlow: {
    position: 'absolute',
    bottom: 20,
    width: 160,
    height: 160,
    borderRadius: 80,
    backgroundColor: '#7C3AED',
  },
  gradCharImg: {
    width: '100%',
    height: 250,
  },

  // Portfolio counter
  portfolioRow: {
    width: '100%',
    backgroundColor: '#0F0520',
    borderRadius: 14,
    padding: 14,
    alignItems: 'flex-end',
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#7C3AED40',
    gap: 4,
  },
  portfolioLabel: {
    color: '#A78BFA',
    fontSize: 11,
    fontFamily: 'Inter_600SemiBold',
  },
  portfolioValue: {
    color: '#FFFFFF',
    fontSize: 24,
    fontFamily: 'Inter_700Bold',
  },
  portfolioReturn: {
    color: '#10B981',
    fontSize: 12,
    fontFamily: 'Inter_600SemiBold',
  },

  // Cert badges row
  certsHint: {
    color: '#9CA3AF',
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    textAlign: 'center',
    marginBottom: 10,
    width: '100%',
  },
  certsRow: {
    flexDirection: 'row-reverse',
    gap: 8,
    justifyContent: 'center',
    marginBottom: 18,
    flexWrap: 'wrap',
  },
  certBadge: {
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 14,
    borderWidth: 2,
    paddingHorizontal: 14,
    paddingVertical: 10,
    gap: 4,
    minWidth: 64,
  },
  certIcon: {
    fontSize: 20,
  },
  certLabel: {
    fontSize: 11,
    fontFamily: 'Inter_700Bold',
  },
  certCheck: {
    fontSize: 10,
  },

  futureBtn: {
    backgroundColor: '#7C3AED',
    borderRadius: 22,
    paddingHorizontal: 20,
    paddingVertical: 12,
    alignSelf: 'stretch',
    alignItems: 'center',
  },
  futureBtnText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontFamily: 'Inter_600SemiBold',
  },
});
