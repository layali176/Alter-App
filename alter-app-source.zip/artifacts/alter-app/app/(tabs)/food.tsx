import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Platform,
  Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather, Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';


const FOOD_ITEMS = [
  { id: 1, name: 'ماك كومبو', price: 45, oldPrice: 54, discount: 30, emoji: '🍟' },
  { id: 2, name: 'بيتزا كبيرة', price: 52, oldPrice: 70, discount: 25, emoji: '🍕' },
  { id: 3, name: 'وجبة دجاج', price: 36, oldPrice: 45, discount: 20, emoji: '🍗' },
];

export default function FoodScreen() {
  const insets = useSafeAreaInsets();
  const [cartCount, setCartCount] = useState(0);
  const [showWarning, setShowWarning] = useState(true);

  const handleAddToCart = (item: typeof FOOD_ITEMS[0]) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setCartCount(c => c + 1);
  };

  const handleThink = () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Alert.alert(
      '💡 لحظة تفكير',
      'اطلب القهوة في البيت وسيوفر عليك 620 ريال هذا الشهر!\n\nهل تريد تحويل المبلغ لمحفظتك الاستثمارية؟',
      [
        { text: 'لا، سأطلب', style: 'cancel' },
        { text: '✅ نعم، ادخار', onPress: () => Alert.alert('🎉 رائع!', 'تم تحويل المبلغ لمحفظتك!') },
      ],
    );
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 12 }]}>
        <View style={styles.cartBadge}>
          {cartCount > 0 && (
            <View style={styles.cartDot}>
              <Text style={styles.cartDotText}>{cartCount}</Text>
            </View>
          )}
          <Ionicons name="cart-outline" size={26} color="#1A1A2E" />
        </View>
        <View style={styles.userInfo}>
          <Text style={styles.greeting}>مرحباً فهد 👋</Text>
          <Text style={styles.greetingSub}>جاهز لطلب الأكل؟ 😅</Text>
        </View>
        <View style={styles.avatar}>
          <Text style={styles.avatarEmoji}>🕴️</Text>
        </View>
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={{ paddingBottom: insets.bottom + 90 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Warning Banner */}
        {showWarning && (
          <View style={styles.warningBanner}>
            <TouchableOpacity style={styles.dismissBtn} onPress={() => setShowWarning(false)}>
              <Feather name="x" size={14} color="#9CA3AF" />
            </TouchableOpacity>
            <View style={styles.warningContent}>
              <Text style={styles.warningTitle}>متأكد بتطلب اكل؟ ⚠️</Text>
              <Text style={styles.warningBody}>
                كم مرة طلبت هذا الشهر؟!{'\n'}
                ترا بتفلس ومصيرك مديون 😂 💸
              </Text>
              <View style={styles.statsRow}>
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>875 SAR</Text>
                  <Text style={styles.statLabel}>المبلغ المنفق</Text>
                </View>
                <View style={styles.statItem}>
                  <Text style={[styles.statValue, { color: '#F59E0B' }]}>14 مرة</Text>
                  <Text style={styles.statLabel}>عدد الطلبات</Text>
                </View>
                <View style={styles.statItem}>
                  <Text style={[styles.statValue, { color: '#10B981' }]}>125 SAR</Text>
                  <Text style={styles.statLabel}>المتبقي من ميزانيتك</Text>
                </View>
              </View>
              <View style={styles.warningButtons}>
                <TouchableOpacity style={styles.thinkBtn} onPress={handleThink} activeOpacity={0.8}>
                  <Text style={styles.thinkBtnText}>🧠 آخذ دقيقة وافكر</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.orderBtn} activeOpacity={0.8}>
                  <Text style={styles.orderBtnText}>اطلب وادفع</Text>
                </TouchableOpacity>
              </View>
              <Text style={styles.warningDisclaimer}>(يس لا تلومنا بعدين 😅)</Text>
            </View>
          </View>
        )}

        {/* Save Banner */}
        <View style={styles.saveBanner}>
          <View style={styles.saveBannerContent}>
            <TouchableOpacity style={styles.saveBannerBtn} activeOpacity={0.8}>
              <Text style={styles.saveBannerBtnText}>📊 شوف كم وفرت هذا الشهر</Text>
            </TouchableOpacity>
            <View>
              <Text style={styles.saveBannerTitle}>وفر فلوسك 💰</Text>
              <Text style={styles.saveBannerSub}>كل طلب اكل = فلوس راحت!</Text>
            </View>
          </View>
        </View>


        {/* Deals */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>عروض تناسبك 😍</Text>
        </View>

        {/* Deals subtitle */}
        <View style={styles.dealsSubtitleRow}>
          <View style={styles.dealsBadge}>
            <Text style={styles.dealsBadgeText}>🏷️ تخفيضات</Text>
          </View>
          <View style={styles.dealsBadge}>
            <Text style={styles.dealsBadgeText}>🎁 عروض</Text>
          </View>
          <Text style={styles.dealsSubtitle}>
            هاذي عروض لك بسبب قراراتك الماليه المميزه ✨
          </Text>
        </View>

        <View style={styles.foodGrid}>
          {FOOD_ITEMS.map((item) => (
            <View key={item.id} style={styles.foodCard}>
              <View style={styles.discountBadge}>
                <Text style={styles.discountText}>خصم {item.discount}%</Text>
              </View>
              <Text style={styles.foodEmoji}>{item.emoji}</Text>
              <Text style={styles.foodName}>{item.name}</Text>
              <View style={styles.foodPriceRow}>
                <TouchableOpacity
                  style={styles.addBtn}
                  onPress={() => handleAddToCart(item)}
                  activeOpacity={0.8}
                >
                  <Feather name="plus" size={16} color="#FFFFFF" />
                </TouchableOpacity>
                <View style={styles.priceInfo}>
                  <Text style={styles.foodPrice}>{item.price} SAR</Text>
                  <Text style={styles.foodOldPrice}>{item.oldPrice} SAR</Text>
                </View>
              </View>
            </View>
          ))}
        </View>

        {/* Friendly reminder */}
        <View style={styles.reminderCard}>
          <Text style={styles.reminderTitle}>🐷 تذكير صديق</Text>
          <Text style={styles.reminderText}>
            انت طلبت أكثر من 13 مرة هذا الشهر و{'\n'}
            <Text style={styles.reminderHighlight}>وفرت 620 SAR </Text>
            لو طبخت في البيت 👨‍🍳
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F3FF',
  },
  header: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#EDE9FE',
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#EDE9FE',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarEmoji: {
    fontSize: 24,
  },
  userInfo: {
    flex: 1,
    alignItems: 'flex-end',
    marginRight: 12,
  },
  greeting: {
    color: '#1A1A2E',
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
  },
  greetingSub: {
    color: '#9CA3AF',
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
  },
  cartBadge: {
    position: 'relative',
  },
  cartDot: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: '#EF4444',
    borderRadius: 8,
    width: 16,
    height: 16,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1,
  },
  cartDotText: {
    color: '#FFFFFF',
    fontSize: 9,
    fontFamily: 'Inter_700Bold',
  },
  scroll: {
    flex: 1,
  },
  warningBanner: {
    margin: 16,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 16,
    shadowColor: '#7C3AED',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 4,
    borderWidth: 1.5,
    borderColor: '#EDE9FE',
  },
  dismissBtn: {
    position: 'absolute',
    top: 12,
    left: 12,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1,
  },
  warningContent: {
    alignItems: 'flex-end',
  },
  warningTitle: {
    color: '#1A1A2E',
    fontSize: 20,
    fontFamily: 'Inter_700Bold',
    textAlign: 'right',
    marginBottom: 6,
  },
  warningBody: {
    color: '#6B7280',
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    marginBottom: 16,
    lineHeight: 20,
  },
  statsRow: {
    flexDirection: 'row-reverse',
    width: '100%',
    justifyContent: 'space-between',
    marginBottom: 16,
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 12,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    color: '#EF4444',
    fontSize: 15,
    fontFamily: 'Inter_700Bold',
  },
  statLabel: {
    color: '#9CA3AF',
    fontSize: 10,
    fontFamily: 'Inter_400Regular',
    textAlign: 'center',
    marginTop: 2,
  },
  warningButtons: {
    flexDirection: 'row-reverse',
    gap: 10,
    width: '100%',
    marginBottom: 8,
  },
  thinkBtn: {
    flex: 1,
    backgroundColor: '#7C3AED',
    borderRadius: 22,
    paddingVertical: 12,
    alignItems: 'center',
  },
  thinkBtnText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontFamily: 'Inter_600SemiBold',
  },
  orderBtn: {
    flex: 1,
    borderRadius: 22,
    paddingVertical: 12,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: '#D1D5DB',
    backgroundColor: '#FFFFFF',
  },
  orderBtnText: {
    color: '#374151',
    fontSize: 13,
    fontFamily: 'Inter_600SemiBold',
  },
  warningDisclaimer: {
    color: '#9CA3AF',
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    textAlign: 'center',
    marginTop: 4,
  },
  saveBanner: {
    marginHorizontal: 16,
    marginBottom: 16,
    backgroundColor: '#EDE9FE',
    borderRadius: 18,
    overflow: 'hidden',
  },
  saveBannerContent: {
    padding: 16,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  saveBannerTitle: {
    color: '#1A1A2E',
    fontSize: 20,
    fontFamily: 'Inter_700Bold',
    textAlign: 'right',
  },
  saveBannerSub: {
    color: '#6B7280',
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
  },
  saveBannerBtn: {
    backgroundColor: '#7C3AED',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  saveBannerBtnText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
  },
  sectionHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 12,
  },
  sectionTitle: {
    color: '#1A1A2E',
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
  },
  seeAll: {
    color: '#7C3AED',
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
  },
  foodGrid: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    paddingHorizontal: 16,
    gap: 10,
    marginBottom: 16,
  },
  foodCard: {
    width: '30%',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 10,
    alignItems: 'center',
    position: 'relative',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 2,
  },
  discountBadge: {
    position: 'absolute',
    top: 6,
    left: 6,
    backgroundColor: '#DC2626',
    borderRadius: 8,
    paddingHorizontal: 5,
    paddingVertical: 2,
  },
  discountText: {
    color: '#FFFFFF',
    fontSize: 8,
    fontFamily: 'Inter_700Bold',
  },
  foodEmoji: {
    fontSize: 36,
    marginVertical: 8,
  },
  foodName: {
    color: '#1A1A2E',
    fontSize: 11,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'center',
    marginBottom: 8,
  },
  foodPriceRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  addBtn: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: '#7C3AED',
    alignItems: 'center',
    justifyContent: 'center',
  },
  priceInfo: {
    alignItems: 'flex-end',
  },
  foodPrice: {
    color: '#1A1A2E',
    fontSize: 12,
    fontFamily: 'Inter_700Bold',
  },
  foodOldPrice: {
    color: '#9CA3AF',
    fontSize: 10,
    textDecorationLine: 'line-through',
    fontFamily: 'Inter_400Regular',
  },
  reminderCard: {
    marginHorizontal: 16,
    marginBottom: 16,
    backgroundColor: '#FEF3C7',
    borderRadius: 18,
    padding: 16,
    borderWidth: 1,
    borderColor: '#FDE68A',
  },
  reminderTitle: {
    color: '#92400E',
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'right',
    marginBottom: 8,
  },
  reminderText: {
    color: '#78350F',
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    lineHeight: 20,
  },
  reminderHighlight: {
    color: '#D97706',
    fontFamily: 'Inter_700Bold',
  },
  dealsSubtitleRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    flexWrap: 'wrap',
    paddingHorizontal: 16,
    gap: 8,
    marginBottom: 14,
  },
  dealsSubtitle: {
    color: '#6B7280',
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    flexShrink: 1,
  },
  dealsBadge: {
    backgroundColor: '#EDE9FE',
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: '#C4B5FD',
  },
  dealsBadgeText: {
    color: '#7C3AED',
    fontSize: 11,
    fontFamily: 'Inter_600SemiBold',
  },
});
