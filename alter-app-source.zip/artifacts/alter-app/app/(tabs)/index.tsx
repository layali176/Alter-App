import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Image,
  StyleSheet,
  Dimensions,
  Animated,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather, Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';

const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get('window');

// ── Falling bill cards ──────────────────────────────────────────
const BILLS = [
  { title: 'كهرباء',   amount: '350 ريال', tag: 'سدد!',    x: 0.05, delay: 0,    dur: 3400, rot: '-14deg' },
  { title: 'إيجار',    amount: '1200 ريال',tag: 'متأخرة',  x: 0.58, delay: 600,  dur: 4100, rot:  '10deg' },
  { title: 'إنترنت',   amount: '120 ريال', tag: 'سدد!',    x: 0.30, delay: 1300, dur: 3000, rot:  '-8deg' },
  { title: 'ماء',      amount: '85 ريال',  tag: 'متأخرة',  x: 0.72, delay: 200,  dur: 4600, rot:  '16deg' },
  { title: 'قرض',      amount: '900 ريال', tag: 'سدد!',    x: 0.14, delay: 2000, dur: 3700, rot: '-20deg' },
  { title: 'تأمين',    amount: '430 ريال', tag: 'متأخرة',  x: 0.44, delay: 2700, dur: 3200, rot:   '6deg' },
  { title: 'كارت',     amount: '640 ريال', tag: 'سدد!',    x: 0.80, delay: 1700, dur: 2800, rot: '-10deg' },
];

// ── A single falling bill card ──────────────────────────────────
function FallingBill({ title, amount, tag, x, delay, dur, rot }: typeof BILLS[0]) {
  const translateY = useRef(new Animated.Value(-110)).current;
  const opacity    = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const anim = Animated.loop(
      Animated.sequence([
        Animated.delay(delay),
        Animated.parallel([
          Animated.timing(translateY, { toValue: SCREEN_H * 0.52, duration: dur, useNativeDriver: true }),
          Animated.sequence([
            Animated.timing(opacity, { toValue: 1,   duration: 250, useNativeDriver: true }),
            Animated.timing(opacity, { toValue: 1,   duration: dur - 500, useNativeDriver: true }),
            Animated.timing(opacity, { toValue: 0,   duration: 250, useNativeDriver: true }),
          ]),
        ]),
        Animated.parallel([
          Animated.timing(translateY, { toValue: -110, duration: 0, useNativeDriver: true }),
          Animated.timing(opacity,    { toValue: 0,    duration: 0, useNativeDriver: true }),
        ]),
      ]),
    );
    anim.start();
    return () => anim.stop();
  }, []);

  return (
    <Animated.View
      style={[
        styles.fallingBillCard,
        { left: SCREEN_W * x, transform: [{ translateY }, { rotate: rot }], opacity },
      ]}
    >
      <View style={styles.billCardTag}>
        <Text style={styles.billCardTagText}>{tag}</Text>
      </View>
      <Text style={styles.billCardTitle}>{title}</Text>
      <Text style={styles.billCardAmount}>{amount}</Text>
    </Animated.View>
  );
}

// ── Main screen ─────────────────────────────────────────────────
export default function ShadowScreen() {
  const insets = useSafeAreaInsets();
  const [paidElectricity, setPaidElectricity] = useState(false);
  const [paidInternet,    setPaidInternet]    = useState(false);
  const [selectedChoice,  setSelectedChoice]  = useState<string | null>(null);

  // Flickering broken-light overlay
  const flickerOpacity = useRef(new Animated.Value(0.62)).current;

  useEffect(() => {
    const flicker = () => {
      Animated.sequence([
        Animated.timing(flickerOpacity, { toValue: 0.72, duration: 80,  useNativeDriver: true }),
        Animated.timing(flickerOpacity, { toValue: 0.55, duration: 60,  useNativeDriver: true }),
        Animated.timing(flickerOpacity, { toValue: 0.75, duration: 40,  useNativeDriver: true }),
        Animated.timing(flickerOpacity, { toValue: 0.60, duration: 120, useNativeDriver: true }),
        Animated.timing(flickerOpacity, { toValue: 0.65, duration: 900, useNativeDriver: true }),
        Animated.delay(Math.random() * 2000 + 1000),
      ]).start(() => flicker());
    };
    const t = setTimeout(flicker, 1500);
    return () => clearTimeout(t);
  }, []);

  // Red vignette pulse
  const vignettePulse = useRef(new Animated.Value(0.18)).current;
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(vignettePulse, { toValue: 0.32, duration: 2800, useNativeDriver: true }),
        Animated.timing(vignettePulse, { toValue: 0.18, duration: 2800, useNativeDriver: true }),
      ]),
    ).start();
  }, []);

  const handlePay = (bill: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    if (bill === 'electricity') setPaidElectricity(true);
    if (bill === 'internet')    setPaidInternet(true);
  };

  const handleChoice = (choice: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setSelectedChoice(choice);
  };

  return (
    <View style={styles.container}>

      {/* ── Hero ───────────────────────────────────────────── */}
      <View style={styles.heroSection}>
        <Image
          source={require('@/assets/images/shadow-hero.png')}
          style={styles.heroImage}
          resizeMode="cover"
        />

        {/* Base dark overlay (flickering) */}
        <Animated.View style={[styles.heroOverlay, { opacity: flickerOpacity }]} />

        {/* Red vignette edges */}
        <Animated.View style={[styles.vignetteOverlay, { opacity: vignettePulse }]} />

        {/* Falling bills — rendered inside hero so they clip naturally */}
        {BILLS.map((b, i) => <FallingBill key={i} {...b} />)}

        {/* Top bar */}
        <View style={[styles.topBar, { paddingTop: insets.top + 12 }]}>
          <View style={styles.balanceBox}>
            <Text style={styles.balanceLabel}>رصيدك</Text>
            <Text style={styles.balanceAmount}>-15,230</Text>
            <Text style={styles.balanceCurrency}>ريال</Text>
          </View>
          <View style={styles.titleBox}>
            <Text style={styles.heroTitle}>صراعتك الماليه{'\n'}تبدا الان</Text>
          </View>
        </View>

        {/* Status Button */}
        <TouchableOpacity style={styles.statusButton} activeOpacity={0.8}>
          <Text style={styles.statusButtonText}>الوضع الحالي</Text>
        </TouchableOpacity>
      </View>

      {/* ── Scroll content ─────────────────────────────────── */}
      <ScrollView
        style={styles.scrollContent}
        contentContainerStyle={{ paddingBottom: insets.bottom + 80, paddingTop: 16 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Shadow caption */}
        <View style={[
          styles.shadowCaption,
          selectedChoice === 'smart' ? styles.shadowCaptionGood : styles.shadowCaptionBad,
        ]}>
          <Text style={[
            styles.shadowCaptionText,
            selectedChoice === 'smart' ? styles.shadowCaptionTextGood : styles.shadowCaptionTextBad,
          ]}>
            {selectedChoice === 'smart'
              ? '✨ هذا ظلك المستقبلي.. ثمرة التزامك المالي اليوم!'
              : '🩸 هذا ظلك الآن.. ضريبة قراراتك المالية اليوم.'}
          </Text>
        </View>

        {/* Bills Section */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeader}>
            <View style={styles.badgePill}>
              <Text style={styles.badgeText}>متأخرة 4</Text>
            </View>
            <View style={styles.sectionTitleRow}>
              <Text style={styles.sectionTitle}>الفواتير المتراكمة والمستحقة</Text>
              <Text style={styles.sectionIcon}>📄</Text>
            </View>
          </View>

          {!paidElectricity ? (
            <View style={styles.billRow}>
              <TouchableOpacity style={styles.payButton} onPress={() => handlePay('electricity')} activeOpacity={0.8}>
                <Text style={styles.payButtonText}>سدد الآن (350$)</Text>
              </TouchableOpacity>
              <View style={styles.billInfo}>
                <Text style={styles.billTitle}>فاتورة الكهرباء المتأخرة ⚡</Text>
                <Text style={styles.billSubtitle}>متأخرة منذ 10 أيام</Text>
              </View>
            </View>
          ) : (
            <View style={[styles.billRow, styles.billPaid]}>
              <View style={styles.paidBadge}>
                <Feather name="check-circle" size={16} color="#10B981" />
                <Text style={styles.paidText}>تم الدفع</Text>
              </View>
              <View style={styles.billInfo}>
                <Text style={styles.billTitlePaid}>فاتورة الكهرباء المتأخرة ⚡</Text>
              </View>
            </View>
          )}

          {!paidInternet ? (
            <View style={[styles.billRow, { marginTop: 10 }]}>
              <TouchableOpacity style={[styles.payButton, { backgroundColor: '#B45309' }]} onPress={() => handlePay('internet')} activeOpacity={0.8}>
                <Text style={styles.payButtonText}>سدد الآن (120$)</Text>
              </TouchableOpacity>
              <View style={styles.billInfo}>
                <Text style={styles.billTitle}>فاتورة الإنترنت المنزلي 🌐</Text>
                <Text style={styles.billSubtitle}>تستحق اليوم</Text>
              </View>
            </View>
          ) : (
            <View style={[styles.billRow, styles.billPaid, { marginTop: 10 }]}>
              <View style={styles.paidBadge}>
                <Feather name="check-circle" size={16} color="#10B981" />
                <Text style={styles.paidText}>تم الدفع</Text>
              </View>
              <View style={styles.billInfo}>
                <Text style={styles.billTitlePaid}>فاتورة الإنترنت المنزلي 🌐</Text>
              </View>
            </View>
          )}
        </View>

        {/* Financial Decision Card */}
        <View style={styles.decisionCard}>
          <View style={styles.decisionHeader}>
            <View style={styles.dailyBadge}>
              <Text style={styles.dailyBadgeText}>هاذا اليومية</Text>
            </View>
            <Text style={styles.decisionTitle}>مواجهة القرار المالي ☕</Text>
          </View>

          <View style={styles.choicesRow}>
            <TouchableOpacity
              style={[styles.choiceCard, styles.emotionalCard, selectedChoice === 'emotional' && styles.selectedCard]}
              onPress={() => handleChoice('emotional')}
              activeOpacity={0.8}
            >
              <Text style={styles.choiceType}>خيار عاطفي/استهلاكي 🛍️</Text>
              <Text style={styles.choiceDesc}>شراء لاتيه فاره ومحلي بـ 35 ريال</Text>
              <Text style={styles.choiceAmount}>-$35</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.choiceCard, styles.smartCard, selectedChoice === 'smart' && styles.selectedSmartCard]}
              onPress={() => handleChoice('smart')}
              activeOpacity={0.8}
            >
              <Text style={styles.choiceTypeSmart}>خيار حكيم/ادخاري 🛡️</Text>
              <Text style={styles.choiceDesc}>تحضير القهوة في المنزل بـ 3 ريال</Text>
              <Text style={styles.choiceAmountSmart}>-$3</Text>
            </TouchableOpacity>
          </View>

          {selectedChoice && (
            <Text style={styles.changeWarning}>
              {selectedChoice === 'smart'
                ? '✅ قرار ذكي! وفرت 32 ريال اليوم'
                : '⚠️ هذا التغيير يسبب قراراتك المالية'}
            </Text>
          )}
        </View>

        {/* Warning Bar */}
        <View style={styles.warningBar}>
          <Ionicons name="warning" size={16} color="#F59E0B" />
          <Text style={styles.warningText}>تنبيه مواجهة العادات المالية</Text>
          <MaterialCommunityIcons name="close-circle" size={16} color="#9CA3AF" />
        </View>

        {/* Stats Row */}
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>32</Text>
            <Text style={styles.statLabel}>يوم بدون ادخار</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={[styles.statValue, { color: '#EF4444' }]}>4</Text>
            <Text style={styles.statLabel}>فواتير متأخرة</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={[styles.statValue, { color: '#F59E0B' }]}>Lv.2</Text>
            <Text style={styles.statLabel}>مستوى الظل</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A0A14',
  },

  // ── Hero ──────────────────────────────────────────────────────
  heroSection: {
    height: 320,
    position: 'relative',
    overflow: 'hidden',
  },
  heroImage: {
    width: '100%',
    height: '100%',
  },
  heroOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: '#060610',
  },
  vignetteOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'transparent',
    borderWidth: 60,
    borderColor: 'rgba(120,10,10,0.55)',
    borderRadius: 0,
  },

  // Falling bill cards
  fallingBillCard: {
    position: 'absolute',
    top: 0,
    backgroundColor: '#FFFDF0',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 7,
    minWidth: 80,
    borderWidth: 1,
    borderColor: '#E5C84A',
    zIndex: 5,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 4,
    elevation: 6,
  },
  billCardTag: {
    backgroundColor: '#DC2626',
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginBottom: 4,
  },
  billCardTagText: {
    color: '#FFFFFF',
    fontSize: 9,
    fontFamily: 'Inter_700Bold',
  },
  billCardTitle: {
    color: '#1A1A1A',
    fontSize: 11,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'center',
  },
  billCardAmount: {
    color: '#DC2626',
    fontSize: 12,
    fontFamily: 'Inter_700Bold',
    textAlign: 'center',
    marginTop: 2,
  },

  // Top bar
  topBar: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    alignItems: 'flex-start',
    zIndex: 10,
  },
  balanceBox: {
    backgroundColor: 'rgba(0,0,0,0.65)',
    borderRadius: 10,
    padding: 8,
    alignItems: 'flex-end',
    borderWidth: 1,
    borderColor: '#EF4444',
  },
  balanceLabel: {
    color: '#9CA3AF',
    fontSize: 10,
    fontFamily: 'Inter_500Medium',
  },
  balanceAmount: {
    color: '#EF4444',
    fontSize: 22,
    fontFamily: 'Inter_700Bold',
  },
  balanceCurrency: {
    color: '#9CA3AF',
    fontSize: 10,
    fontFamily: 'Inter_400Regular',
  },
  titleBox: {
    alignItems: 'flex-end',
  },
  heroTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontFamily: 'Inter_700Bold',
    textAlign: 'right',
    maxWidth: 180,
    lineHeight: 26,
  },
  statusButton: {
    position: 'absolute',
    bottom: 20,
    alignSelf: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 28,
    paddingVertical: 12,
    borderRadius: 30,
    zIndex: 10,
  },
  statusButtonText: {
    color: '#0A0A14',
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'center',
  },

  // ── Scroll ────────────────────────────────────────────────────
  scrollContent: {
    flex: 1,
    paddingHorizontal: 16,
  },

  // Shadow caption
  shadowCaption: {
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 14,
    borderWidth: 1,
    alignItems: 'flex-end',
  },
  shadowCaptionBad: {
    backgroundColor: 'rgba(239,68,68,0.08)',
    borderColor: 'rgba(239,68,68,0.25)',
  },
  shadowCaptionGood: {
    backgroundColor: 'rgba(16,185,129,0.08)',
    borderColor: 'rgba(16,185,129,0.30)',
  },
  shadowCaptionText: {
    fontSize: 13,
    fontFamily: 'Inter_500Medium',
    textAlign: 'right',
    lineHeight: 20,
  },
  shadowCaptionTextBad:  { color: '#FCA5A5' },
  shadowCaptionTextGood: { color: '#6EE7B7' },

  // Bills card
  sectionCard: {
    backgroundColor: '#14101E',
    borderRadius: 20,
    padding: 16,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#2D2040',
  },
  sectionHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
  },
  sectionTitleRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 6,
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'right',
  },
  sectionIcon: { fontSize: 18 },
  badgePill: {
    backgroundColor: '#2D2040',
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  badgeText: {
    color: '#A78BFA',
    fontSize: 11,
    fontFamily: 'Inter_500Medium',
  },
  billRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  billPaid: { opacity: 0.6 },
  billInfo: { flex: 1, alignItems: 'flex-end' },
  billTitle: {
    color: '#FFFFFF',
    fontSize: 14,
    fontFamily: 'Inter_500Medium',
    textAlign: 'right',
  },
  billTitlePaid: {
    color: '#9CA3AF',
    fontSize: 14,
    fontFamily: 'Inter_500Medium',
    textAlign: 'right',
    textDecorationLine: 'line-through',
  },
  billSubtitle: {
    color: '#9CA3AF',
    fontSize: 11,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    marginTop: 2,
  },
  payButton: {
    backgroundColor: '#DC2626',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 22,
  },
  payButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontFamily: 'Inter_600SemiBold',
  },
  paidBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(16,185,129,0.15)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  paidText: {
    color: '#10B981',
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
  },

  // Decision card
  decisionCard: {
    backgroundColor: '#14101E',
    borderRadius: 20,
    padding: 16,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#2D2040',
  },
  decisionHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  dailyBadge: {
    backgroundColor: '#7C3AED',
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  dailyBadgeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontFamily: 'Inter_500Medium',
  },
  decisionTitle: {
    color: '#FFFFFF',
    fontSize: 15,
    fontFamily: 'Inter_600SemiBold',
    textAlign: 'right',
  },
  choicesRow: {
    flexDirection: 'row-reverse',
    gap: 10,
  },
  choiceCard: {
    flex: 1,
    borderRadius: 14,
    padding: 12,
    borderWidth: 1.5,
    borderColor: '#2D2040',
  },
  emotionalCard:    { backgroundColor: '#1A0A0A', borderColor: '#7F1D1D' },
  smartCard:        { backgroundColor: '#0A1A10', borderColor: '#14532D' },
  selectedCard:     { borderColor: '#EF4444',    backgroundColor: '#2D0A0A' },
  selectedSmartCard:{ borderColor: '#10B981',    backgroundColor: '#0A2A15' },
  choiceType: {
    color: '#FCA5A5',
    fontSize: 10,
    fontFamily: 'Inter_500Medium',
    textAlign: 'right',
    marginBottom: 4,
  },
  choiceTypeSmart: {
    color: '#6EE7B7',
    fontSize: 10,
    fontFamily: 'Inter_500Medium',
    textAlign: 'right',
    marginBottom: 4,
  },
  choiceDesc: {
    color: '#D1D5DB',
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
    textAlign: 'right',
    marginBottom: 6,
  },
  choiceAmount:      { color: '#EF4444', fontSize: 16, fontFamily: 'Inter_700Bold', textAlign: 'right' },
  choiceAmountSmart: { color: '#10B981', fontSize: 16, fontFamily: 'Inter_700Bold', textAlign: 'right' },
  changeWarning: {
    color: '#D1D5DB',
    fontSize: 12,
    fontFamily: 'Inter_400Regular',
    textAlign: 'center',
    marginTop: 12,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#2D2040',
  },

  // Warning bar
  warningBar: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#1A1200',
    borderRadius: 30,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#F59E0B40',
  },
  warningText: {
    flex: 1,
    color: '#FCD34D',
    fontSize: 12,
    fontFamily: 'Inter_500Medium',
    textAlign: 'right',
  },

  // Stats
  statsRow: {
    flexDirection: 'row-reverse',
    gap: 10,
    marginBottom: 14,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#14101E',
    borderRadius: 16,
    padding: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#2D2040',
  },
  statValue: {
    color: '#A78BFA',
    fontSize: 22,
    fontFamily: 'Inter_700Bold',
  },
  statLabel: {
    color: '#9CA3AF',
    fontSize: 10,
    fontFamily: 'Inter_400Regular',
    textAlign: 'center',
    marginTop: 4,
  },
});
